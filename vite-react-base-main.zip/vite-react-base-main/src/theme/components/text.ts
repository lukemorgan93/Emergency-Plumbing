export const Text = {
  baseStyle: {
    fontFeatureSettings:
      '"ss07" on, "ss02" on, "ss03" on, "ss04" on, "ss05" on, "ss06" on',
  },
  variants: {
    display: {
      fontFamily: `'Helvetica Now Display', sans-serif`,
    },
  },
}
