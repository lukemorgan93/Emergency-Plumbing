import { describe } from 'vitest'

describe('Have you Created Tests?', () => {
  it.todo('Just reminding you')
})
